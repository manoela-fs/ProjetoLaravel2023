<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Produto;
use DB;

class ProdutoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        try {
            $produtos = DB::select('SELECT produtos.*, Tipo_Produtos.descricao AS tipo_produto_descricao FROM produtos JOIN Tipo_Produtos ON produtos.Tipo_Produtos_id = Tipo_Produtos.id');
            return view("Produto/index")->with("produtos", $produtos);
        } catch (\Throwable $th) {
            return view("Produto/index")->with("produtos", [])->with("message", [$th->getMessage(), "danger"]);
        }
    }

    public function indexMessage($message)
    {
        try {
            $produtos = DB::select('SELECT produtos.*, Tipo_Produtos.descricao AS tipo_produto_descricao FROM produtos JOIN Tipo_Produtos ON produtos.Tipo_Produtos_id = Tipo_Produtos.id');
            return view("Produto/index")->with("produtos", $produtos)->with("message", $message);
        } catch (\Throwable $th) {
            return view("Produto/index")->with("produtos", [])->with("message", [$th->getMessage(), "danger"]);
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        try {
            // $tipoProdutos = TipoProduto::all();
            $tipoProdutos = DB::select('select * from Tipo_Produtos');
            // dd($tipoProdutos);
            return view("Produto/create")->with("tipoProdutos", $tipoProdutos);;
        } catch (\Throwable $th) {
            return $this->indexMessage([$th->getMessage(), "danger"]);
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        try {
            $produto = new Produto();
            $produto->nome = $request->nome;
            $produto->preco = $request->preco;
            $produto->Tipo_Produtos_id = $request->Tipo_Produtos_id;
            $produto->ingredientes = $request->ingredientes;
            $produto->urlImage = $request->urlImage;

            $produto->save();
            return $this->indexMessage(["Produto cadastrado com sucesso!", "success"]); //roda o método atualizando a view index
        } catch (\Throwable $th) {
            return $this->indexMessage([$th->getMessage(), "danger"]);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        try {
            $produto = DB::select("select produtos.*, 
                                    Tipo_Produtos.descricao AS tipo_produto_descricao 
                               FROM produtos 
                               JOIN Tipo_Produtos ON produtos.Tipo_Produtos_id = Tipo_Produtos.id
                               where produtos.id = ?", [$id]);
            //dd($produto);
            if (count($produto) == 0) {
                return $this->indexMessage(["Produto não encontrado.", "warning"]);
            }
            return view("Produto/show")->with("produto", $produto[0]);
        } catch (\Throwable $th) {
            return $this->indexMessage([$th->getMessage(), "danger"]);
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        try {
            $produto = Produto::find($id);
            $tipoProdutos = DB::select('select * from Tipo_Produtos');
            //dd($produto);

            if (isset($produto)) {
                return view("Produto/edit")->with("produto", $produto)->with("tipoProdutos", $tipoProdutos);
            } else {
                return $this->indexMessage(["Produto não encontrado.", "warning"]);
            }
        } catch (\Throwable $th) {
            return $this->indexMessage([$th->getMessage(), "danger"]);
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        try {
            $produto = Produto::find($id);

            if (isset($produto)) {
                $produto->nome = $request->nome;
                $produto->preco = $request->preco;
                $produto->Tipo_Produtos_id = $request->Tipo_Produtos_id;
                $produto->ingredientes = $request->ingredientes;
                $produto->urlImage = $request->urlImage;
                $produto->update();

                return $this->indexMessage(["Produto editado com sucesso!", "success"]);
            } else {
                return $this->indexMessage(["Produto não encontrado.", "warning"]);
            }
        } catch (\Throwable $th) {
            return $this->indexMessage([$th->getMessage(), "danger"]);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        try {

            $produto = Produto::find($id);

            if (isset($produto)) {
                $produto->delete();
                return $this->indexMessage(["Produto removido com sucesso!", "success"]);
            } else {
                return $this->indexMessage(["Produto não encontrado.", "warning"]);
            }
        } catch (\Throwable $th) {
            return $this->indexMessage([$th->getMessage(), "danger"]);
        }
    }
}
