<?php

use Illuminate\Support\Facades\Route;
use App\Models\Produto;
use App\Models\TipoProduto;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

// Route::get('ola/{nome}/{sobrenome}', function ($nome, $sobrenome) {
//     echo "Olá! Seja bem-vindo(a) $nome $sobrenome";
// });

// Route::get('ola/{nome?}', function ($nome=null) {
//     if (isset($nome)) {
//         echo "Olá! Seja bem-vindo(a) $nome"; 
//     }
//     else{
//         echo "Olá! Seja bem-vindo(a)";
//     }
// });

Route::get("tipoproduto/add/{descricao}", function ($descricao) {
    $tipoProduto = new TipoProduto;
    $tipoProduto->descricao = $descricao;
    $tipoProduto->save();
    echo "Dado salvo com sucesso!";
});

Route::get("produto/add/{nome}/{preco}/{Tipo_Produtos_id}/{ingredientes}/{urlImage}", function ($nome, $preco, $Tipo_Produtos_id, $ingredientes = null, $urlImage = null) {
    $produto = new Produto;
    $produto->nome = $nome;
    $produto->preco = $preco;
    $produto->Tipo_Produtos_id = $Tipo_Produtos_id;
    $produto->ingredientes = $ingredientes;
    $produto->urlImage = $urlImage;
    $produto->save();
    echo "Dado salvo com sucesso!";
});

//Rotas TipoProduto
// Route::get("/tipoproduto", "\App\Http\Controllers\TipoProdutoController@index")->name("tipoproduto.index");
// Route::get("/tipoproduto/create", "\App\Http\Controllers\TipoProdutoController@create")->name("tipoproduto.create");
// Route::post("/tipoproduto", "\App\Http\Controllers\TipoProdutoController@store")->name("tipoproduto.store");
// Route::get("/tipoproduto/{id}", "\App\Http\Controllers\TipoProdutoController@show")->name("tipoproduto.show");
// Route::get("/tipoproduto/{id}/edit", "\App\Http\Controllers\TipoProdutoController@edit")->name("tipoproduto.edit");
// Route::put("/tipoproduto/{id}", "\App\Http\Controllers\TipoProdutoController@update")->name("tipoproduto.update");

Route::resource('tipoproduto', "\App\Http\Controllers\TipoProdutoController");

//Rotas Produto
// Route::get("/produto", "\App\Http\Controllers\ProdutoController@index")->name("produto.index");
// Route::get("/produto/create", "\App\Http\Controllers\ProdutoController@create")->name("produto.create");
// Route::post("/produto", "\App\Http\Controllers\ProdutoController@store")->name("produto.store");
// Route::get("/produto/{id}", "\App\Http\Controllers\ProdutoController@show")->name("produto.show");
// Route::get("/produto/{id}/edit", "\App\Http\Controllers\ProdutoController@edit")->name("produto.edit");
// Route::put("/produto/{id}", "\App\Http\Controllers\ProdutoController@update")->name("produto.update");
// Route::delete("/produto/{id}", "\App\Http\Controllers\ProdutoController@destroy")->name("produto.destroy");

Route::resource('produto', "\App\Http\Controllers\ProdutoController");

