<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
</head>
<body class="bg-primary-subtle">
    <div class="container pt-5">
        <form class="row p-4 col-lg-6 border rounded ms-auto me-auto bg-light-subtle shadow-lg" method="POST" action="<?php echo e(route("produto.update", $produto->id)); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <h2 class="text-center">Editar produto</h2>
            

            <div class="mb-3">
              <label for="id-input-nome" class="form-label">Nome</label>
              <input name="nome" type="text" class="form-control" id="id-input-nome" value="<?php echo e($produto->nome); ?>">
            </div>

            <div class="col-6 mb-3">
              <label for="id-input-preco" class="form-label">Preço</label>
              <input name="preco" type="number" class="form-control" id="id-input-preco" value="<?php echo e($produto->preco); ?>">
            </div>

            <div class="col-6 mb-3">
              <label for="id-input-tipoProduto" class="form-label">Tipo Produto</label>
              <select name="Tipo_Produtos_id" class="form-select" aria-label="Selecione">
                <?php $__currentLoopData = $tipoProdutos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipoProduto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($tipoProduto->id == $produto->Tipo_Produtos_id): ?>
                  <option value="<?php echo e($tipoProduto->id); ?>" selected><?php echo e($tipoProduto->descricao); ?></option>
                  <?php else: ?>
                  <option value="<?php echo e($tipoProduto->id); ?>"><?php echo e($tipoProduto->descricao); ?></option>
                  <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
            
            <div class="mb-3">
              <label for="id-input-ingredientes" class="form-label">Ingredientes</label>
              <textarea name="ingredientes" type="text" class="form-control" id="id-input-ingredientes"><?php echo e($produto->ingredientes); ?></textarea>
            </div>

            <div class="mb-3">
              <label for="id-input-urlImage" class="form-label">UrlImage</label>
              <input name="urlImage" class="form-control" type="text" id="id-input-urlImage" value="<?php echo e($produto->urlImage); ?>">
            </div>

            <div class="input-group mb-3 row mt-2 ms-auto me-auto">
              <a href="<?php echo e(route("produto.index")); ?>" class="btn btn-secondary col-6">Cancelar</a>
              <button type="submit" class="btn btn-primary col-6">Salvar</button>
            </div>
          </form>
    </div>
</body>
</html><?php /**PATH C:\Users\Aluno\Documents\ProjetoAula2023\resources\views/Produto/edit.blade.php ENDPATH**/ ?>