<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
</head>
<body class="bg-primary-subtle">
    <div class="container pt-5">
        <div class="row p-4 col-lg-6 border rounded ms-auto me-auto bg-light-subtle shadow-lg">
            <h2 class="text-center"><?php echo e($tipoProduto->descricao); ?></h2>
            <div class="mb-3">
              <label for="id-input-id" class="form-label">Id</label>
              <input type="text" class="form-control" id="id" aria-describedat="id-help-id" value="<?php echo e($tipoProduto->id); ?>" disabled>
            </div>
            <div class="mb-3 col-lg-6">
              <label for="id-input-updated_at" class="form-label">Atualizado em</label>
              <input class="form-control" type="text" id="id-input-updated_at" value="<?php echo e($tipoProduto->updated_at); ?>" disabled>
            </div>

            <div class="mb-4 col-lg-6">
              <label for="id-input-created_at" class="form-label">Criado em</label>
              <input class="form-control" type="text" id="id-input-created_at" value="<?php echo e($tipoProduto->created_at); ?>" disabled>
            </div>

            <div class="input-group mb-3 row mt-2 ms-auto me-auto">
              <a href="<?php echo e(route("tipoproduto.index")); ?>" class="btn btn-secondary col-6">Voltar</a>
              <a href="<?php echo e(route('tipoproduto.edit', $tipoProduto->id)); ?>" class="btn btn-primary col-6">Editar</a>
            </div>
          </div>
        </div>

          
    </div>
</body>
</html><?php /**PATH C:\Users\Aluno\Documents\ProjetoAula2023\resources\views/TipoProduto/show.blade.php ENDPATH**/ ?>