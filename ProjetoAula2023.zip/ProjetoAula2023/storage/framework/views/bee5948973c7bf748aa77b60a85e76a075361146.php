<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
</head>
<body class="bg-primary-subtle">
    <div class="container pt-5">
        <div class="row p-4 col-lg-6 border rounded ms-auto me-auto bg-light-subtle shadow-lg">
            <h2 class="text-center"><?php echo e($produto->nome); ?></h2>
            <div class="mb-3 col-3">
              <label for="id-input-id" class="form-label">Id</label>
              <input type="text" class="form-control" id="id-input-id" value="<?php echo e($produto->id); ?>" disabled>
            </div>
            <div class="mb-3 col-5">
              <label for="id-input-tipo" class="form-label">Tipo</label>
              <input type="text" class="form-control" id="id-input-tipo" value="<?php echo e($produto->tipo_produto_descricao); ?>" disabled>
            </div>
            <div class="mb-3 col-4">
              <label for="id-input-preco" class="form-label">Preço</label>
              <input type="number" class="form-control" id="id-input-preco" value="<?php echo e($produto->preco); ?>" disabled>
            </div>
            
            <div class="mb-3">
              <label for="id-input-ingredientes" class="form-label">Ingredientes</label>
              <textarea name="ingredientes" type="text" class="form-control" id="id-input-ingredientes" disabled><?php echo e($produto->ingredientes); ?></textarea>
            </div>

            <div class="mb-3">
              <label for="id-input-urlImage" class="form-label">UrlImage</label>
              <input class="form-control" type="text" id="id-input-urlImage" value="<?php echo e($produto->urlImage); ?>" disabled>
            </div>

            <div class="mb-3 col-lg-6">
              <label for="id-input-updated_at" class="form-label">Atualizado em</label>
              <input class="form-control" type="text" id="id-input-updated_at" value="<?php echo e($produto->updated_at); ?>" disabled>
            </div>

            <div class="mb-4 col-lg-6">
              <label for="id-input-created_at" class="form-label">Criado em</label>
              <input class="form-control" type="text" id="id-input-created_at" value="<?php echo e($produto->created_at); ?>" disabled>
            </div>

            <div class="input-group mb-3 row mt-2 ms-auto me-auto">
              <a href="<?php echo e(route("produto.index")); ?>" class="btn btn-secondary col-6">Voltar</a>
              <a href="<?php echo e(route('produto.edit', $produto->id)); ?>" class="btn btn-primary col-6">Editar</a>
            </div>
          </div>
          
    </div>
</body>
</html><?php /**PATH C:\Users\Aluno\Documents\ProjetoAula2023\resources\views/Produto/show.blade.php ENDPATH**/ ?>