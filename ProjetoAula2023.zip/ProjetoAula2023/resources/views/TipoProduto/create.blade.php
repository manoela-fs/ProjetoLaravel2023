<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
</head>
<body class="bg-primary-subtle">
    <div class="container pt-5">
        <form class="p-4 col-lg-6 border rounded ms-auto me-auto bg-light-subtle shadow-lg" method="post" action="{{route("tipoproduto.store")}}">
            @csrf
            <h2 class="text-center">Cadastrar tipo de produto</h2>
            <div class="mb-3">
              <label for="id-input-id" class="form-label">Id</label>
              <input type="text" class="form-control" id="id" aria-describedat="id-help-id" value="#" disabled>
              <div id="id-help-id" class="form-text">Não é necessário informar um ID para cadastrar um novo dado.</div>
            </div>
            <div class="mb-3">
              <label for="id-input-descricao" class="form-label">Descrição</label>
              <input name="descricao" type="text" class="form-control" id="id-input-descricao">
            </div>
            <div class="input-group mb-3 row mt-2 ms-auto me-auto">
              <a href="{{route("tipoproduto.index")}}" class="btn btn-secondary col-6">Cancelar</a>
              <button type="submit" class="btn btn-primary col-6">Cadastrar</button>
            </div>
          </form>

          
    </div>
</body>
</html>